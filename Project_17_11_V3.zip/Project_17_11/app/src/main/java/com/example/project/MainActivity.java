package com.example.project;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.rits.cloning.Cloner;

import java.util.ArrayList;

public class MainActivity extends Activity {

    CanvasSetting canvasSetting;

    class MyGraphicsView extends View {
        Point centerPoint;
        Paint topPaint =new Paint();
        Paint bottomPaint =new Paint();
        Paint leftPaint =new Paint();
        Paint rightPaint =new Paint();
        Paint centerPaint =new Paint();
        RectF centerRect;
        MovingRectangle movingRectFromLeft;
        MovingRectangle movingRectFromRight;
        ArrayList<Triangle> triangleList = new ArrayList<>();
        ValueAnimator animation;
        boolean isCollided;

        float left = 0;
        float right = 0;
        float top = 0;
        float bottom = 0;

        public void setDimension()
        {
            centerPoint = new Point(canvasSetting.getCenterPointX(),canvasSetting.getCenterPointY());
            left = canvasSetting.getCenterPointX() - (canvasSetting.getRectWidth() / 2);
            Log.d("Left", String.valueOf(left));
            right = canvasSetting.getCenterPointX() + (canvasSetting.getRectWidth() / 2);
            Log.d("Right", String.valueOf(right));
            top = canvasSetting.getCenterPointY() - (canvasSetting.getRectHeight() / 2);
            Log.d("Top", String.valueOf(top));
            bottom = canvasSetting.getCenterPointY() + (canvasSetting.getRectHeight() / 2);
            Log.d("Bottom", String.valueOf(bottom));
        }

        public void setPaint()
        {
            centerPaint.setColor(Color.TRANSPARENT);
            centerPaint.setStyle(Paint.Style.FILL);
            topPaint.setColor(Color.RED);
            topPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            bottomPaint.setColor(Color.BLUE);
            bottomPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            leftPaint.setColor(Color.GREEN);
            leftPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            rightPaint.setColor(Color.YELLOW);
            rightPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        }

        public void setCenterSquare()
        {
            Triangle triangleLeft = new Triangle(centerPoint, canvasSetting.getRectWidth(), "left");
            Triangle triangleRight = new Triangle(centerPoint, canvasSetting.getRectWidth(), "right");
            Triangle triangleTop = new Triangle(centerPoint, canvasSetting.getRectWidth(), "top");
            Triangle triangleBottom = new Triangle(centerPoint, canvasSetting.getRectWidth(), "bottom");
            triangleList.add(triangleLeft);
            triangleList.add(triangleTop);
            triangleList.add(triangleRight);
            triangleList.add(triangleBottom);
        }

        public MyGraphicsView(Context context)
        {
            super(context);
            setDimension();
            setPaint();
            setCenterSquare();
            centerRect = new RectF(left,top,right,bottom);
            movingRectFromLeft = new MovingRectangle(0, top, 0 + (canvasSetting.getRectWidth()/4), bottom, leftPaint);

            setupAnimate(movingRectFromLeft);

            movingRectFromRight = new MovingRectangle(0, top, 0 + (canvasSetting.getRectWidth()/4), bottom, leftPaint);

            this.postDelayed(new Runnable() {
                public void run() {
                    setupAnimate(new MovingRectangle(0, top, 0 + (canvasSetting.getRectWidth()/4), bottom, leftPaint));
                }
            }, 10000);
            //setupAnimate(movingRectFromLeft);
        }

        public void rotate()
        {
            Cloner cloner = new Cloner();
            Triangle tempLeftTriangle = cloner.deepClone(triangleList.get(0));
            cloner = new Cloner();
            Triangle tempTopTriangle = cloner.deepClone(triangleList.get(1));
            cloner = new Cloner();
            Triangle tempRightTriangle = cloner.deepClone(triangleList.get(2));
            cloner = new Cloner();
            Triangle tempBottomTriangle = cloner.deepClone(triangleList.get(3));

                triangleList.get(0).setLeftPoint(tempTopTriangle.getLeftPoint());
                triangleList.get(0).setRightPoint(tempTopTriangle.getRightPoint());
            System.out.println(triangleList.get(0).getLeftPoint().toString());
            System.out.println(triangleList.get(0).getRightPoint().toString());
            System.out.println(triangleList.get(0).getPaint().getColor());
            triangleList.get(0).setNewPath();
            triangleList.get(0).setColor("red");

                triangleList.get(1).setLeftPoint(tempRightTriangle.getLeftPoint());
                triangleList.get(1).setRightPoint(tempRightTriangle.getRightPoint());
            System.out.println(triangleList.get(1).getPaint().getColor());
            triangleList.get(1).setNewPath();
            triangleList.get(1).setColor("yellow");

                triangleList.get(2).setLeftPoint(tempBottomTriangle.getLeftPoint());
                triangleList.get(2).setRightPoint(tempBottomTriangle.getRightPoint());
            triangleList.get(2).setNewPath();
            triangleList.get(2).setColor("blue");

                triangleList.get(3).setLeftPoint(tempLeftTriangle.getLeftPoint());
                triangleList.get(3).setRightPoint(tempLeftTriangle.getRightPoint());
            triangleList.get(3).setNewPath();
            triangleList.get(3).setColor("green");
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int touchX = (int) event.getX();
            int touchY = (int) event.getY();
            switch(event.getAction()){
                case MotionEvent.ACTION_DOWN:
                    System.out.println("Touching down!");
                        if(centerRect.contains(touchX,touchY)){
                            System.out.println("Touched Center Rectangle, Rotate View!!!.");
                            rotate();
                        }
                    break;
                case MotionEvent.ACTION_UP:
                    System.out.println("Touching up!");
                    break;
                case MotionEvent.ACTION_MOVE:
                    System.out.println("Sliding your finger around on the screen.");
                    break;
            }
            return true;
        }

        @Override
        protected void onDraw(Canvas canvas){
            canvas.drawColor(Color.TRANSPARENT);
            canvas.drawRect(centerRect, centerPaint);

            for(Triangle t : triangleList)
            {
                canvas.drawPath(t.getPath(), t.getPaint());
            }

            //Log.d("Moving Rect status",movingRect.toString());

            if(!movingRectFromLeft.intersect(centerRect))
            {
                canvas.drawRect(movingRectFromLeft,movingRectFromLeft.getPaint());
            }
            else
            {
                Toast.makeText(MainActivity.this, "Intersected!!!", Toast.LENGTH_SHORT)
                        .show();
            }
        }



        protected void setupCenterSquare(Point centerPoint, int width)
        {
        	Triangle topTriangle = new Triangle(centerPoint, width, "top");
        	Triangle bottomTriangle = new Triangle(centerPoint, width, "bottom");
        	Triangle leftTriangle = new Triangle(centerPoint, width, "left");
        	Triangle rightTriangle = new Triangle(centerPoint, width, "right");
        }

        public void checkCollision(MovingRectangle animatedRect)
        {
            //animatedRect.intersect();
        }
        
        protected void setupAnimate(final MovingRectangle animatedRect){
            float translateX = 200.0f;
            float translateY = 0.0f;
            ObjectAnimator animateLeft = ObjectAnimator.ofFloat(animatedRect, "left", animatedRect.left, animatedRect.left + translateX);
            animatedRect.setLeft(animatedRect.left + translateX);
            ObjectAnimator animateRight = ObjectAnimator.ofFloat(animatedRect, "right", animatedRect.right, animatedRect.right+translateX);
            animatedRect.setRight(animatedRect.right + translateX);
            ObjectAnimator animateTop = ObjectAnimator.ofFloat(animatedRect, "top", animatedRect.top, animatedRect.top+translateY);
            animatedRect.setTop(animatedRect.top + translateY);
            ObjectAnimator animateBottom = ObjectAnimator.ofFloat(animatedRect, "bottom", animatedRect.bottom, animatedRect.bottom+translateY);
            animatedRect.setBottom(animatedRect.bottom + translateY);
            animateBottom.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    checkCollision(animatedRect);
                    postInvalidate();
                }
            });
            AnimatorSet rectAnimation = new AnimatorSet();
            rectAnimation.playTogether(animateLeft, animateRight, animateTop, animateBottom);
            rectAnimation.setDuration(8000).start();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle data = getIntent().getExtras();
        this.canvasSetting = (CanvasSetting) data.getParcelable("CanvasSetting");
        Log.d("CanvasSetting", this.canvasSetting.toString());
        setContentView(new MyGraphicsView(this));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(com.example.project.R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
